Kaltura JavaScript API Client Library tests

To run tests:
 - Rename config.template.js to config.js and replace configuration tokens
 - npm install
 - karma start
 - karma run
