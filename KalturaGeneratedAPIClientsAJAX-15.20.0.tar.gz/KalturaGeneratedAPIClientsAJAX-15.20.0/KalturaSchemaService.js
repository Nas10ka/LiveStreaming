
/**
 *Class definition for the Kaltura service: schema.
 **/
var KalturaSchemaService = {

}
