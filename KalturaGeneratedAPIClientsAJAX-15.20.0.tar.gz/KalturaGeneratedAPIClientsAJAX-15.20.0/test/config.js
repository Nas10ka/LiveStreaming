
var secret = "@YOUR_ADMIN_SECRET@";
var partnerId = @YOUR_PARTNER_ID@;
var serviceUrl = "@SERVICE_URL@";
